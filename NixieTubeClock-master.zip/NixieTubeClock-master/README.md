# NixieTubeClock
辉光管时钟开源版本

成品如图所示：

<img src="https://pic1.zhimg.com/275438a2962254892ffcf6884ed78b5c_b.jpg" style="width: 50%; height: 50%"/>
<img src="https://pic4.zhimg.com/3e41665f7d843dd7f6aa6ece630f09e8_b.jpg" style="width: 50%; height: 50%"/>


* PCB制版可在[深圳市嘉立创科技发展有限公司](www.sz-jlc.com/)制作；
* 大部分元器件可在[立创商城](www.szlcsc.com/)购买；
* 剩余部分元器件（如辉光管、拨动开关、继电器等）可在淘宝直接购买，具体型号及规格如下图所示：

<img src="https://raw.githubusercontent.com/niklaus520/NixieTubeClock/master/BOM/QQ20160517-0%402x.png" style="width: 50%; height: 50%"/>
<img src="https://raw.githubusercontent.com/niklaus520/NixieTubeClock/master/BOM/QQ20160517-1%402x.png" style="width: 50%; height: 50%"/>


**最后要强调一点，没有电子制作经验的朋友慎入这个坑，我懂大部分都是想做出来送给自己的另一半的，但是还有更好的选择对不对？比如Tiffany的💍。**

祝各位美好。
